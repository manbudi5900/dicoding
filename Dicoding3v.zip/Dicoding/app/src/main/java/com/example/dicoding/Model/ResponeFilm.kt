package com.example.dicoding.Model

data class ResponseFilm (
    var results:Array<Film>
)
data class ResponseTv (
    var results:Array<Tv>
)