package com.example.dicoding.Model

import android.os.Parcel
import android.os.Parcelable

class ImageModel (
    var name: String? = null,
    var image_drawable: String? = null,
    var desc: String? = null,
    var reles: String? = null,
    var genre: String? = null,
    var rate: Double?=null

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Double::class.java.classLoader) as? Double
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(image_drawable)
        parcel.writeString(desc)
        parcel.writeString(reles)
        parcel.writeString(genre)
        parcel.writeValue(rate)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ImageModel> {
        override fun createFromParcel(parcel: Parcel): ImageModel {
            return ImageModel(parcel)
        }

        override fun newArray(size: Int): Array<ImageModel?> {
            return arrayOfNulls(size)
        }
    }
}