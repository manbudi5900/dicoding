package com.example.dicoding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.dicoding.Model.ImageModel
import kotlinx.android.synthetic.main.activity_detail.*


class Detail : AppCompatActivity() {
    companion object {
        const val EXTRA_PERSON = "extra_person"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val film = intent.getParcelableExtra(EXTRA_PERSON) as ImageModel
        Glide.with(this)
            .load(film.image_drawable.toString())
            .into(image)
        name.setText(film.name.toString())
        film.rate?.toFloat()?.let { rt.setRating(it) }
        rat.setText(film.rate.toString())
        desc1.setText(film.desc)
        reles.setText(film.reles)
        genre.setText(film.genre)
    }
}



