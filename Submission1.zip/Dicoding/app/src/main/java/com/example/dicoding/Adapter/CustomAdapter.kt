package com.example.dicoding.Adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.dicoding.Model.ImageModel
import kotlinx.android.synthetic.main.item.view.*
import android.net.Uri
import androidx.appcompat.widget.AppCompatRatingBar
import com.example.dicoding.R

import com.bumptech.glide.Glide


class CustomAdapter(private val context: Context, private val imageModelArrayList: ArrayList<ImageModel>) : BaseAdapter() {

    override fun getViewTypeCount(): Int {
        return count
    }

    override fun getItemViewType(position: Int): Int {

        return position
    }

    override fun getCount(): Int {
        return imageModelArrayList.size
    }

    override fun getItem(position: Int): Any {
        return imageModelArrayList[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    @SuppressLint("ResourceType")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var convertView = convertView
        val holder: ViewHolder

        if (convertView == null) {
            holder = ViewHolder()
            val inflater = context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = inflater.inflate(R.layout.item, null, true)

            holder.tvname = convertView!!.name as TextView
            holder.dc = convertView!!.desc as TextView
            holder.iv = convertView.imgView as ImageView
            holder.rt1 = convertView!!.rt as AppCompatRatingBar

            convertView.tag = holder
        } else {
            // the getTag returns the viewHolder object set as a tag to the view
            holder = convertView.tag as ViewHolder
        }

        holder.tvname!!.setText(imageModelArrayList[position].name)

        holder.dc!!.setText(imageModelArrayList[position].desc?.subSequence(0,40))
        Glide.with(convertView.context)
            .load(imageModelArrayList[position].image_drawable)
            .placeholder(R.color.colorPrimary)
            .error(R.color.colorPrimary)
            .into(holder.iv)
        imageModelArrayList[position].rate?.toFloat()?.let { holder.rt1!!.setRating(it) }
        return convertView
    }

    private inner class ViewHolder {

        var tvname: TextView? = null
        internal var iv: ImageView? = null
        var rt1: AppCompatRatingBar? = null
        var dc: TextView? = null

    }

}