package com.example.dicoding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.dicoding.Model.Film

import kotlinx.android.synthetic.main.activity_detail.*
import kotlinx.android.synthetic.main.activity_detail.desc1
import kotlinx.android.synthetic.main.activity_detail.rt
import kotlinx.android.synthetic.main.detail_coba.*


class Detail : AppCompatActivity() {
    companion object {
        const val EXTRA_PERSON = "extra_person"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detail_coba)
        val film = intent.getParcelableExtra(EXTRA_PERSON) as Film
        Glide.with(this)
            .load(film.image_drawable.toString())
            .into(imageView2)

        Glide.with(this)
            .load(film.image_drawable.toString())
            .into(imageView3)


        textView7.setText(film.name.toString())
        film.rate?.toFloat()?.let { rt.setRating(it) }
        desc1.setText(film.desc)
        textView10.setText(film.menit)
        textView8.setText(film.genre)
        Toast.makeText(this,film.menit, Toast.LENGTH_SHORT).show()
    }
}



