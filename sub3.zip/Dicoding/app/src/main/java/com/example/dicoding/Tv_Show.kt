package com.example.dicoding

import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dicoding.Adapter.CustomAdapter
import com.example.dicoding.Model.Film
import kotlinx.android.synthetic.main.coba.*

class Tv_Show : Fragment() {
    private val handler = Handler()

    private val myImageList = arrayOf(
        "https://image.tmdb.org/t/p/w154/ff1zhqvwfS5HvRNcA5UFrH0PA2q.jpg",
        "https://image.tmdb.org/t/p/w154/gKG5QGz5Ngf8fgWpBsWtlg5L2SF.jpg",
        "https://image.tmdb.org/t/p/w154/yTZQkSsxUFJZJe67IenRM0AEklc.jpg",
        "https://image.tmdb.org/t/p/w154/qJdfO3ahgAMf2rcmhoqngjBBZW1.jpg",
        "https://image.tmdb.org/t/p/w154/mg2fUxfH3ktaWqbSq4oL3g3yyCm.jpg",
        "https://image.tmdb.org/t/p/w154/BbNvKCuEF4SRzFXR16aK6ISFtR.jpg",
        "https://image.tmdb.org/t/p/w154/wHa6KOJAoNTFLFtp7wguUJKSnju.jpg",
        "https://image.tmdb.org/t/p/w154/cDDb7WA2i7cENhkEEjXEDrXGyNL.jpg",
        "https://image.tmdb.org/t/p/w154/gBGUL1UTUNmdRQT8gA1LUV4yg39.jpg",
        "https://image.tmdb.org/t/p/w154/KoYWXbnYuS3b0GyQPkbuexlVK9.jpg"
    )


    private val myImageNameList = arrayOf(
        "Vikings",
        "Arrow",
        "The Simpsons",
        "Rick and Morty",
        "True Cooking Master Boy",
        "The Mandalorian",
        "The Flash",
        "Doctor Who",
        "Family Guy",
        "Supernatural"
    )

    private val myRateList = arrayListOf(
        7.5,
        5.9,
        7.2,
        8.6,
        8.0,
        8.0,
        6.8,
        7.0,
        6.5,
        7.5
    )

    private val genre = arrayOf(
        "Drama",
        "Adventure",
        "Action",
        "Crime",
        "Action",
        "Comedy",
        "Adventure",
        "Action",
        "Drama",
        "Drama")


    private val menit = arrayOf(
        "2013",
        "2012",
        "1989",
        "2013",
        "2019",
        "2019",
        "2014",
        "2005",
        "1999",
        "2005")
    val back = arrayOf(
        "https://image.tmdb.org/t/p/original/aq2yEMgRQBPfRkrO0Repo2qhUAT.jpg",
        "https://image.tmdb.org/t/p/original/dKxkwAJfGuznW8Hu0mhaDJtna0n.jpg",
        "https://image.tmdb.org/t/p/original/f5uNbUC76oowt5mt5J9QlqrIYQ6.jpg",
        "https://image.tmdb.org/t/p/original/mzzHr6g1yvZ05Mc7hNj3tUdy2bM.jpg",
        "https://image.tmdb.org/t/p/original/glHLRL0zgKXKHwBm7NOD2jqNx9a.jpg",
        "https://image.tmdb.org/t/p/original/o7qi2v4uWQ8bZ1tW3KI0Ztn2epk.jpg",
        "https://image.tmdb.org/t/p/original/6ZdQTBy20HzWudZthAV7NkZWfIb.jpg",
        "https://image.tmdb.org/t/p/original/nfH8SZJVOxcBlFaqqtoqS5hHizG.jpg",
        "https://image.tmdb.org/t/p/original/pH38r4TWTqq7Mcs6XAlwgzNUeJe.jpg",
        "https://image.tmdb.org/t/p/original/o9OKe3M06QMLOzTl3l6GStYtnE9.jpg"
    )

    val produser = arrayOf(
        "James Gray",
        "J.J. Abrams",
        "Todd Phillips",
        "Jake Kasdan",
        "Joon-Ho Bong",
        "Joachim Ronning",
        "Wilson Yip",
        "Greta Gerwig",
        "Sam Mendes",
        "Chris Buck & Jennifer Lee"
    )
    val negara = arrayOf(
        "Amerika Serikat",
        "Amerika Serikat",
        "Kanada",
        "Amerika Serikat",
        "Korea",
        "Amerika Serikat",
        "Hongkong",
        "Amerika Serikat",
        "Amerika Serikat",
        "Amerika Serikat"
    )

    val list1 = ArrayList<Film>()


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.coba, container, false)
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list.setVisibility(View.GONE)
        val mydeskList = getResources().getStringArray(R.array.tv)
        list.setHasFixedSize(true)
        list.layoutManager = LinearLayoutManager(this.context)

        for (i in 0 until menit.size){
            list1.add(Film(
                myImageNameList[i],
                myImageList[i],
                mydeskList[i],
                menit[i],
                genre[i],
                back[i],
                produser[i],
                negara[i],
                myRateList[i]
            ))
            if(menit.size - 1 == i){
                // init adapter yang telah dibuat tadi
                val adapter = CustomAdapter(list1)
                ShowProgressDialog()
                adapter.notifyDataSetChanged()
                //tampilkan data dalam recycler view
                list.adapter = adapter
            }
        }

    }
    fun ShowProgressDialog() {

        var status = 0
        Thread(Runnable {
            while (status < 15) {
                status += 1
                try {
                    Thread.sleep(200)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                handler.post(Runnable {
                    progress_bar.setProgress(status)

                    if (status === 15) {
                        progress_bar.setVisibility(View.GONE)
                        list.setVisibility(View.VISIBLE)
                    }
                })
            }
        }).start()

    }
}