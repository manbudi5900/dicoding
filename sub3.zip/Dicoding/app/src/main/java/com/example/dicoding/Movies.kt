package com.example.dicoding

import android.content.Intent
import android.database.Observable
import android.os.Bundle
import android.os.Handler
import android.telecom.Call
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dicoding.Adapter.CustomAdapter
import com.example.dicoding.Model.Film
import kotlinx.android.synthetic.main.coba.*

class Movies : Fragment() {
    private val handler = Handler()

    private val myImageList = arrayOf(
        "https://image.tmdb.org/t/p/w154/xBHvZcjRiWyobQ9kxBhO6B2dtRI.jpg",
        "https://image.tmdb.org/t/p/w154/db32LaOibwEliAmSL2jjDF6oDdj.jpg",
        "https://image.tmdb.org/t/p/w154/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg",
        "https://image.tmdb.org/t/p/w154/jyw8VKYEiM1UDzPB7NsisUgBeJ8.jpg",
        "https://image.tmdb.org/t/p/w154/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg",
        "https://image.tmdb.org/t/p/w154/vloNTScJ3w7jwNwtNGoG8DbTThv.jpg",
        "https://image.tmdb.org/t/p/w154/yJdeWaVXa2se9agI6B4mQunVYkB.jpg",
        "https://image.tmdb.org/t/p/w154/mSmiB8XjUnR1GSIljuCPGsk0cwX.jpg",
        "https://image.tmdb.org/t/p/w154/AuGiPiGMYMkSosOJ3BQjDEAiwtO.jpg",
        "https://image.tmdb.org/t/p/w154/pjeMs3yqRmFL3giJy4PMXWZTTPa.jpg"
    )

    private val myImageNameList = arrayOf(
        "Ad Astra",
        "Star Wars: The Rise of Skywalker",
        "Joker",
        "Jumanji: The Next Level",
        "Parasite",
        "Maleficent: Mistress of Evil",
        "Ip Man 4: The Finale",
        "Little Women",
        "1917",
        "Frozen II"
    )

    private val myRateList = arrayListOf(
        6.0,
        6.6,
        6.7,
        6.7,
        8.6,
        7.2,
        6.0,
        8.3,
        8.0,
        7.0
    )

    private val genre = arrayOf(
        "Action",
        "Action",
        "Adventure",
        "Adventure",
        "Petualangan",
        "Action",
        "Action",
        "Animation",
        "Komedi",
        "Horor")


    private val tahun = arrayOf(
        "2019",
        "2019",
        "2019",
        "2019",
        "2019",
        "2019",
        "2019",
        "2019",
        "2019",
        "2019")
    val back = arrayOf(
        "https://image.tmdb.org/t/p/original/5BwqwxMEjeFtdknRV792Svo0K1v.jpg",
        "https://image.tmdb.org/t/p/original/jOzrELAzFxtMx2I4uDGHOotdfsS.jpg",
        "https://image.tmdb.org/t/p/original/n6bUvigpRFqSwmPp1m2YADdbRBc.jpg",
        "https://image.tmdb.org/t/p/original/zTxHf9iIOCqRbxvl8W5QYKrsMLq.jpg",
        "https://image.tmdb.org/t/p/original/TU9NIjwzjoKPwQHoHshkFcQUCG.jpg",
        "https://image.tmdb.org/t/p/original/skvI4rYFrKXS73BJxWGH54Omlvv.jpg",
        "https://image.tmdb.org/t/p/original/ekP6EVxL81lZ4ivcqPsoZ72rY0h.jpg",
        "https://image.tmdb.org/t/p/original/3uTxPIdVEXxHpsHOHdJC24QebBV.jpg",
        "https://image.tmdb.org/t/p/original/tUWivz05fcY14K6RzicRm7IHkUD.jpg",
        "https://image.tmdb.org/t/p/original/xJWPZIYOEFIjZpBL7SVBGnzRYXp.jpg"
    )
    val produser = arrayOf(
        "Michael Hirst",
        "Greg Berlanti, Marc Guggenheim & Andrew Kreisberg",
        "David Silverman",
        "Dan Harmon & Justin Roiland",
        "Masami Anno",
        "Jon Favreau",
        "Greg Berlanti, Geoff Johns & Andrew Kreisberg",
        "Sydney Newman",
        "Seth Macfarlane",
        "Eric Kripke"
    )
    val negara = arrayOf(
        "Kanada",
        "Amerika Serikat",
        "Amerika Serikat",
        "Amerika Serikat",
        "Tiongkok",
        "Amerika Serikat",
        "Amerika Serikat",
        "Inggris",
        "Amerika Serikat",
        "Amerika Serikat"
    )
    val list1 = ArrayList<Film>()


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.coba, container, false)
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        list.setVisibility(View.GONE)
        val mydeskList = getResources().getStringArray(R.array.movies)
        list.setHasFixedSize(true)
        list.layoutManager = LinearLayoutManager(this.context)
        for (i in 0 until tahun.size){
            list1.add(Film(
                myImageNameList[i],
                myImageList[i],
                mydeskList[i],
                tahun[i],
                genre[i],
                back[i],
                produser[i],
                negara[i],
                myRateList[i]
            ))

            if(tahun.size - 1 == i){
                val adapter = CustomAdapter(list1)
                ShowProgressDialog()
                adapter.notifyDataSetChanged()
                list.adapter = adapter
            }
        }

    }
    fun ShowProgressDialog() {

        var status = 0
        Thread(Runnable {
            while (status < 15) {
                status += 1
                try {
                    Thread.sleep(200)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
                handler.post(Runnable {
                    progress_bar.setProgress(status)

                    if (status === 15) {
                        progress_bar.setVisibility(View.GONE)
                        list.setVisibility(View.VISIBLE)
                    }
                })
            }
        }).start()

    }

}


