package com.example.dicoding.Model

import android.os.Parcel
import android.os.Parcelable

class Film (
    var name: String? = null,
    var image_drawable: String? = null,
    var desc: String? = null,
    var menit: String? = null,
    var genre: String? = null,
    var rate: Double?=null

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readValue(Double::class.java.classLoader) as? Double

    ) 

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(image_drawable)
        parcel.writeString(desc)
        parcel.writeString(menit)
        parcel.writeString(genre)
        parcel.writeValue(rate)

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Film> {
        override fun createFromParcel(parcel: Parcel): Film {
            return Film(parcel)
        }

        override fun newArray(size: Int): Array<Film?> {
            return arrayOfNulls(size)
        }
    }
}