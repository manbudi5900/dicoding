package com.example.dicoding

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.dicoding.Adapter.CustomAdapter
import com.example.dicoding.Model.Film


import kotlinx.android.synthetic.main.coba.*

class Movies : Fragment() {
    private val myImageList = arrayOf(
        "https://akcdn.detik.net.id/community/media/visual/2019/03/12/97e6931e-52d7-4a0d-a088-d7e1bf4c95cb.jpeg?a=1",
        "https://assets-a2.kompasiana.com/items/album/2018/09/08/sumber-www-kaskus-co-id-5b93e7f2aeebe1055254fa84.jpeg?t=o&v=350",
        "https://cdn-brilio-net.akamaized.net/news/2019/07/01/166475/1059078-film-indonesia-juli-2019.jpg",
        "https://merahputih.com/media/44/1b/f7/441bf7dd77ab1c8c5763885052473c8c.jpg",
        "https://cdn-brilio-net.akamaized.net/news/2018/11/14/154992/947952-7-film-indonesia-bergenre-horor-paling-banyak-penontonnya-2018.jpg",
        "https://cdn0-production-images-kly.akamaized.net/W_fM88xPB6eu2nUo3sMK13zALG0=/640x360/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/2929587/original/026181000_1570099366-1.jpg",
        "https://s3.bukalapak.com/uploads/content_attachment/3400cbec30e8d762196074c5/w-744/film_horor_terbaik_6.jpg",
        "https://ecs7.tokopedia.net/blog-tokopedia-com/uploads/2017/10/film-horror-2.jpg",
        "https://statik.tempo.co/data/2013/08/01/id_207273/207273_620.jpg",
        "https://assets.jalantikus.com/assets/cache/500/500/userfiles/2019/05/15/Tokoh-Hantu-Terseram-di-Film-Horor-3-3bd62.jpg")


    private val myImageNameList = arrayOf(
        "Munafik",
        "Sebelum Iblis Menjemput",
        "Ikut Aku Ke Neraka",
        "Mata Batin",
        "Rasuk",
        "Bernafas Dalam Kubur",
        "Kuntilanak",
        "The Nun",
        "Sumpah Pocong",
        "Awas Ada Setan")

    private val myRateList = arrayListOf(5.0, 1.2, 2.1, 2.9, 1.9, 1.5, 3.2, 2.1, 0.9, 1.9)

    private val genre = arrayOf(
        "Komedi",
        "Horor",
        "Horor",
        "Horor",
        "Horor",
        "Horor",
        "Horor",
        "Horor",
        "Horor",
        "Horor")
//    private val mydeskList = arrayOf(
//        "Film horor Kelam yang dibintangi Aura Kasih rilis di bioskop-bioskop Indonesia mulai hari ini, Kamis (24/10/2019). Film horor Indonesia ini bercerita sejak kabur dari rumah delapan tahun, hubungan Nina (Aura Kasih) dan mamanya, Dewi (Rina Hassim) menjadi dingin. Sebuah permasalahan yang sepertinya cukup besar membuat mereka saling enggan bertegur sapa. Namun kecelakaan yang menimpa Dewi membuat adik Nina, Fenny (Amanda Manopo) memanggil Nina untuk kembali pulang. Walaupun ada masalah yang lama, rasa bakti Nina kepada Dewi sepertinya masih mengakar di hatinya. Nina pulang untuk bertemu dengan ibunya. Setelah pertemuan itu, hubungan Nina dan Dewi berangsur membaik. Saat itu, Nina datang bersama anaknya, Sasha (Giselle Tambunan) yang berusia tujuh tahun. Namun hal yang tidak terduga justru terjadi saat Sasha tidak sadarkan diri. Setelah diperiksa, dia mengalami kebocoran jantung dan perlu donor.",
//        "Kisahnya berfokus pada Samantha yang memiliki kemampuan magis untuk memanggil kuntilanak. Setelah kematian sang ibu dan mendapat gangguan-gangguan dari ayah tirinya, Samantha/Sam memutuskan menyewa kamar kost di pinggiran kota",
//        "Keramat merupakan film horor dari Indonesia yang dirilis pada tahun 2009 dan disutradarai oleh Monty Tiwa. Film ini dibintangi oleh Poppy Sovia, Migi Parahita, Sadha Triyudha, Miea Kusuma, Dimas Projosujadi, Diaz Ardiawan, serta Brama Sutasara.",
//        "Kafir menggambarkan tentang satu keluarga yang mengalami kejadian tak terduga. Pada suatu malam, sang bapak (Teddy Syah) kesakitan dan mengeluarkan beling dari mulutnya sebelum meninggal dunia",
//        "Film garapan Joko Anwar ini merupakan versi adaptasi dari horor lawas berjudul sama pada medio 80-an. Pengabdi Setan versi Joko bercerita soal perjuangan keras satu keluarga setelah ibu mereka yang sudah lama sakit akhirnya meninggal dunia",
//        "Film horor thriller rilisan 2010 ini disutradarai Mo Brothers yang mengangkat kisah sekelompok pemuda terjebak di rumah milik seorang pembunuh misterius bernama Dara",
//        "Film yang paling menyeramkan yang diambil dari kisah nyata adalah The Conjuring. Cerita dalam film ini diambil dari kisah pasangan paranormal Ed dan Lorraine Warren. Film ini dirilis tahun 2013. Ceritanya, ada sebuah keluarga yang diganggu sama hantu Bathseba, yaitu pengikut aliran sekte yang mengutuk rumah itu",
//        "Boneka Annabelle ini ternyata memang ada di kehidupan nyata lho, Loopers. Kejadian tragis menimpa keluarga kecil yang menemukan boneka Annabelle. Film yang dirilis pada 2014 lalu ini juga masih diproduseri oleh spesialis film horor, James Wan",
//        "Film ini diambil dari kisah yang terjadi di wilayah Connecticut, Amerika Serikat, dimana ada salah satu rumah yang aneh. Di dalam rumah itu selalu terjadi kejadian aneh hingga melibatkan paranormal ternama kayak Ed dan Lorraine Warren",
//        "Film yang dirilis tahun 2005 ini ada seorang gadis bernama Emily Rose yang kisahnya diambil dari gadis bernama Anneliese Michel. Dalam film itu, Emily ini mengalami kejang parah, lalu lama kelamaan menyerang keluarganya satu persatu. Akibatnya, Emily harus menjalani ritual pengusiran setan di dalam tubuhnya selama 40 hari")


//    val mydeskList = hello.split("/").toTypedArray()
//    val mydeskList1 = hello.split("/").toTypedArray()



    private val menit = arrayOf(
        "102 mins",
        "92 mins",
        "140 mins",
        "102 mins",
        "120 mins",
        "152 mins",
        "100 mins",
        "109 mins",
        "109 mins",
        "110 mins")
    val list1 = ArrayList<Film>()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.coba, container, false)
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val mydeskList = getResources().getStringArray(R.array.movies)
        list.setHasFixedSize(true)
        list.layoutManager = LinearLayoutManager(this.context)
        for (i in 0 until menit.size){
            list1.add(Film(
                myImageNameList[i],
                myImageList[i],
                mydeskList[i],
                menit[i],
                genre[i],
                myRateList[i]
            ))
            if(menit.size - 1 == i){
                val adapter = CustomAdapter(list1)
                adapter.notifyDataSetChanged()
                list.adapter = adapter
            }
        }

    }
}


