package com.example.dicoding.Adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

import kotlinx.android.synthetic.main.item.view.*
import android.net.Uri
import android.widget.Toast
import androidx.appcompat.widget.AppCompatRatingBar
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.dicoding.Detail
import com.example.dicoding.Model.Film
import com.example.dicoding.R



class CustomAdapter(private val film: ArrayList<Film>): RecyclerView.Adapter<CustomAdapter.Holder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        return Holder(LayoutInflater.from(parent.context).inflate(R.layout.item,parent,false))
    }

    override fun getItemCount(): Int = film?.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.view.name.text = film?.get(position)?.name
        holder.view.desc.text = film?.get(position)?.desc
        Glide.with(holder.view.context)
            .load(film?.get(position)?.image_drawable)
            .placeholder(R.color.colorPrimary)
            .error(R.color.colorPrimary)
            .into(holder.view.imgView)
        film?.get(position)?.rate?.toFloat()?.let { holder.view.rt.setRating(it) }
        holder.view.setOnClickListener{
//            Toast.makeText(holder.view.context, film?.get(position)?.menit, Toast.LENGTH_SHORT).show()
            val film = Film(
                film?.get(position)?.name,
                film?.get(position)?.image_drawable,
                film?.get(position)?.desc,
                film?.get(position)?.menit,
                film?.get(position)?.genre,
                film?.get(position)?.rate

            )
            val moveWithObjectIntent = Intent(holder.view.context, Detail::class.java)
            moveWithObjectIntent.putExtra(Detail.EXTRA_PERSON, film)
            holder.view.context.startActivity(moveWithObjectIntent)
        }


    }


    class Holder(val view: View) : RecyclerView.ViewHolder(view)


}