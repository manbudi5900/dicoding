package com.example.dicoding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.dicoding.Adapter.CustomAdapter
import com.example.dicoding.Model.Film
import kotlinx.android.synthetic.main.coba.*

class Tv_Show : Fragment() {
    private val myImageList = arrayOf(
        "https://dansmedia.net/wp-content/uploads/2019/02/mojito-1.png",
        "https://cdn2.tstatic.net/banjarmasin/foto/bank/images/drama-korea-lets-eat-3_20180720_123325.jpg",
        "https://koreanmusicblog1.files.wordpress.com/2018/01/monday-kiz-my-first-love-ost-part-1.jpg?w=700",
        "https://2.bp.blogspot.com/-NT7cyshgWb0/Wq9AqMyE90I/AAAAAAAAGiA/v1tEmo3a2zQyboXuRAtWV7-Lw8_4E9_ugCLcBGAs/s1600/ohsoo.jpg",
        "https://i.mydramalist.com/4w03Yc.jpg",
        "https://i.mydramalist.com/dwJ7Ac.jpg",
        "http://asianwiki.com/images/e/ec/Radio_Romance-P1.jpg",
        "https://m.media-amazon.com/images/I/91eQ2NDCDbL._SS500_.jpg",
        "https://dansmedia.net/wp-content/uploads/2019/02/unusual.png",
        "https://i.mydramalist.com/RPPorc.jpg")


    private val myImageNameList = arrayOf(
        "Mojito",
        "Lets Eat 3",
        "Longing Heart (My First Love)",
        "That Man Oh Soo 2018",
        "A Poem a Day / You Who Forgot Poetry",
        "Rich Man, Poor Woman",
        "Radio Romance",
        "Romantic Comedy King",
        "Unusual Men and Women",
        "Nice Witch")

    private val myRateList = arrayListOf(1.0, 1.2, 2.1, 2.9, 1.9, 1.5, 3.2, 2.1, 0.9, 1.9)

    private val genre = arrayOf(
        "Romance",
        "Romance",
        "Roamnce",
        "Horor, Komedi",
        "Romantis, Horor",
        "Komedi, Horor",
        "Horor",
        "Fantasi, Horor",
        "Komedi, Horor",
        "Horor")


    private val menit = arrayOf(
        "102 mins",
        "92 mins",
        "140 mins",
        "102 mins",
        "120 mins",
        "152 mins",
        "100 mins",
        "109 mins",
        "109 mins",
        "110 mins")
    val list1 = ArrayList<Film>()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? =
        inflater.inflate(R.layout.coba, container, false)
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val mydeskList = getResources().getStringArray(R.array.tv)
        list.setHasFixedSize(true)
        list.layoutManager = LinearLayoutManager(this.context)

        for (i in 0 until menit.size){

            list1.add(Film(
                myImageNameList[i],
                myImageList[i],
                mydeskList[i],
                menit[i],
                genre[i],
                myRateList[i]
            ))

            if(menit.size - 1 == i){
                // init adapter yang telah dibuat tadi
                val adapter = CustomAdapter(list1)
                adapter.notifyDataSetChanged()

                //tampilkan data dalam recycler view
                list.adapter = adapter
            }
        }

    }
}